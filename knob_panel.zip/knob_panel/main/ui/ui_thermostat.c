/*
 * SPDX-FileCopyrightText: 2023 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: CC0-1.0
 */

#include "lvgl.h"
#include <stdio.h>
#include "ui_thermostat.h"

#include "bsp/esp-bsp.h"
#include "settings.h"
#include "tasks.h"
#include "lv_example_pub.h"
#include "lv_example_image.h"
#include "lighting_effect_task.h"

static lv_obj_t *temp_arc;
static lv_obj_t *page;
static lv_obj_t *temp_wheel;
static time_out_count time_500ms;
//setting up map
static int map_temp_to_brightness(uint8_t temperature);

static bool thermostat_layer_enter_cb(void *layer);
static bool thermostat_layer_exit_cb(void *layer);
static void thermostat_layer_timer_cb(lv_timer_t *tmr);

lv_layer_t thermostat_Layer = {
    .lv_obj_name    = "thermostat_Layer",
    .lv_obj_parent  = NULL,
    .lv_obj_layer   = NULL,
    .lv_show_layer  = NULL,
    .enter_cb       = thermostat_layer_enter_cb,
    .exit_cb        = thermostat_layer_exit_cb,
    .timer_cb       = thermostat_layer_timer_cb,
};
//case for brightness 
static int map_temp_to_brightness(uint8_t temperature) {
    switch (temperature) {
        case 19: return 25;  // 25% brightness
        case 20: return 30;  // 30% brightness
        case 21: return 40;  // 40% brightness
        case 22: return 50;  // 50% brightness
        case 23: return 60;  // 60% brightness
        case 24: return 70;  // 70% brightness
        case 25: return 75;  // 75% brightness
        case 26: return 85;  // 85% brightness
        case 27: return 90;  // 90% brightness
        case 28: return 95;  // 95% brightness
        case 29: return 100; // 100% brightness
        case 30: return 100; // 100% brightness
        default: return 0;   // Default to 0% brightness
    }
}
static void thermostat_event_cb(lv_event_t *e)
{
    uint8_t current;
    lv_event_code_t code = lv_event_get_code(e);

    if (LV_EVENT_FOCUSED == code) {
        lv_group_set_editing(lv_group_get_default(), true);
    } else if (LV_EVENT_KEY == code) {

        if (is_time_out(&time_500ms)) {
            uint32_t key = lv_event_get_key(e);
            current = lv_arc_get_value(temp_arc);

            if (LV_KEY_RIGHT == key) {
                if (current < lv_arc_get_max_value(temp_arc)) {
                    current++;
                }
            } else if (LV_KEY_LEFT == key) {
                if (current > lv_arc_get_min_value(temp_arc)) {
                    current--;
                }
            }

            lv_arc_set_value(temp_arc, current);
            lv_roller_set_selected(temp_wheel, (current - 19), LV_ANIM_ON);

            // Map temperature to brightness
            int brightness = map_temp_to_brightness(current);
            printf("Thermostat Temp: %d -> Brightness: %d\n", current, brightness);  // Debug log

            // Update brightness level for lighting effect task
            set_brightness_level(brightness);
        }
    } else if (LV_EVENT_LONG_PRESSED == code) {
        lv_indev_wait_release(lv_indev_get_next(NULL));
        ui_remove_all_objs_from_encoder_group();
        lv_func_goto_layer(&menu_layer);
    }
}


//event for roller
static void mask_event_cb(lv_event_t *e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t *obj = lv_event_get_target(e);

    static int16_t mask_top_id = -1;
    static int16_t mask_bottom_id = -1;

    if (code == LV_EVENT_COVER_CHECK) {
        lv_event_set_cover_res(e, LV_COVER_RES_MASKED);
    } else if (code == LV_EVENT_VALUE_CHANGED) {
        char buf[32];
        lv_roller_get_selected_str(obj, buf, sizeof(buf));
        LV_LOG_USER("Selected value: %s", buf);
    } else if (code == LV_EVENT_DRAW_MAIN_BEGIN) {
        /* add mask */
        const lv_font_t *font = lv_obj_get_style_text_font(obj, LV_PART_MAIN);
        lv_coord_t line_space = lv_obj_get_style_text_line_space(obj, LV_PART_MAIN);
        lv_coord_t font_h = lv_font_get_line_height(font);

        lv_area_t roller_coords;
        lv_obj_get_coords(obj, &roller_coords);

        lv_area_t rect_area;
        rect_area.x1 = roller_coords.x1;
        rect_area.x2 = roller_coords.x2;
        rect_area.y1 = roller_coords.y1;
        rect_area.y2 = roller_coords.y1 + (lv_obj_get_height(obj) - font_h - line_space) / 2;

        lv_draw_mask_fade_param_t *fade_mask_top = lv_mem_buf_get(sizeof(lv_draw_mask_fade_param_t));
        lv_draw_mask_fade_init(fade_mask_top, &rect_area, LV_OPA_TRANSP, rect_area.y1, LV_OPA_COVER, rect_area.y2);
        mask_top_id = lv_draw_mask_add(fade_mask_top, NULL);

        rect_area.y1 = rect_area.y2 + font_h + line_space - 1;
        rect_area.y2 = roller_coords.y2;

        lv_draw_mask_fade_param_t *fade_mask_bottom = lv_mem_buf_get(sizeof(lv_draw_mask_fade_param_t));
        lv_draw_mask_fade_init(fade_mask_bottom, &rect_area, LV_OPA_COVER, rect_area.y1, LV_OPA_TRANSP, rect_area.y2);
        mask_bottom_id = lv_draw_mask_add(fade_mask_bottom, NULL);

    } else if (code == LV_EVENT_DRAW_POST_END) {
        lv_draw_mask_fade_param_t *fade_mask_top = lv_draw_mask_remove_id(mask_top_id);
        lv_draw_mask_fade_param_t *fade_mask_bottom = lv_draw_mask_remove_id(mask_bottom_id);
        lv_draw_mask_free_param(fade_mask_top);
        lv_draw_mask_free_param(fade_mask_bottom);
        lv_mem_buf_release(fade_mask_top);
        lv_mem_buf_release(fade_mask_bottom);
        mask_top_id = -1;
        mask_bottom_id = -1;
    }
}
//event for roller
static void roller_event_cb(lv_event_t *e) {
    lv_obj_t *roller = lv_event_get_target(e);

    // Get the selected value from the roller as a string
    char buf[32];
    lv_roller_get_selected_str(roller, buf, sizeof(buf));
    int selected_temp = atoi(buf);  // Convert the string to an integer

    // Map the temperature to brightness
    int brightness = map_temp_to_brightness(selected_temp);

    // Log for debugging
    printf("Selected Temp: %d -> Brightness: %d\n", selected_temp, brightness);

    // Update the lighting effect based on the brightness level
    set_brightness_level(brightness);
}


/**
 * Add a fade mask to roller.
 */
void lv_create_obj_roller(lv_obj_t *parent) {
    // Initialize the style for the roller
    static lv_style_t style;
    lv_style_init(&style);
    lv_style_set_bg_color(&style, lv_color_black());
    lv_style_set_bg_opa(&style, LV_OPA_0);
    lv_style_set_text_color(&style, lv_color_white());
    lv_style_set_border_width(&style, 0);
    lv_style_set_pad_all(&style, 0);
    lv_obj_add_style(lv_scr_act(), &style, 0);

    // Create the roller object
    temp_wheel = lv_roller_create(parent);
    lv_obj_add_style(temp_wheel, &style, 0);

    printf("line_space:%d\r\n", lv_obj_get_style_text_line_space(temp_wheel, LV_PART_MAIN));
    lv_obj_set_style_text_line_space(temp_wheel, 40, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(temp_wheel, LV_OPA_TRANSP, LV_PART_SELECTED);

#if LV_FONT_MONTSERRAT_48
    lv_obj_set_style_text_font(temp_wheel, &lv_font_montserrat_48, LV_PART_SELECTED);
#endif

    // Set options for the roller (temperature values)
    lv_roller_set_options(temp_wheel,
                          "19\n"
                          "20\n"
                          "21\n"
                          "22\n"
                          "23\n"
                          "24\n"
                          "25\n"
                          "26\n"
                          "27\n"
                          "28\n"
                          "29\n"
                          "30",
                          LV_ROLLER_MODE_NORMAL);

    // Align the roller to the parent container
    lv_obj_align(temp_wheel, LV_ALIGN_CENTER, 5, 10);
    lv_roller_set_visible_row_count(temp_wheel, 3);

    // Attach event callback for handling value changes
    lv_obj_add_event_cb(temp_wheel, roller_event_cb, LV_EVENT_VALUE_CHANGED, NULL);

    // Attach mask_event_cb for additional functionality (e.g., fade effect)
    lv_obj_add_event_cb(temp_wheel, mask_event_cb, LV_EVENT_ALL, NULL);
}


void ui_thermostat_init(lv_obj_t *parent) {
    // Create the main page
    page = lv_obj_create(parent);
    lv_obj_set_size(page, LV_HOR_RES, LV_VER_RES);
    lv_obj_set_style_border_width(page, 0, 0);
    lv_obj_set_style_radius(page, 0, 0);
    lv_obj_clear_flag(page, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_center(page);

    // Default temperature and brightness setup
    int default_temp = 22;
    int default_brightness = map_temp_to_brightness(default_temp);

    // Initialize the roller
    lv_create_obj_roller(parent);
    lv_roller_set_selected(temp_wheel, (default_temp - 19), LV_ANIM_ON);

    // Set the initial brightness level
    set_brightness_level(default_brightness);

    // Add background image
    lv_obj_t *img_thermostat_bg = lv_img_create(page);
    lv_img_set_src(img_thermostat_bg, &AC_BG);
    lv_obj_align(img_thermostat_bg, LV_ALIGN_CENTER, 0, 0);

    // Add temperature icon
    lv_obj_t *img_thermostat_temp = lv_img_create(page);
    lv_img_set_src(img_thermostat_temp, &AC_temper);
    lv_obj_align(img_thermostat_temp, LV_ALIGN_CENTER, 0, 20);

    // Create the arc (temperature gauge)
    temp_arc = lv_arc_create(page);
    lv_obj_set_size(temp_arc, LV_HOR_RES - 40, LV_VER_RES - 40);
    lv_arc_set_rotation(temp_arc, 180 + (180 - 150) / 2);
    lv_arc_set_bg_angles(temp_arc, 0, 150);
    lv_arc_set_value(temp_arc, default_temp);
    lv_arc_set_range(temp_arc, 19, 30);
    lv_obj_set_style_arc_width(temp_arc, 10, LV_PART_MAIN);
    lv_obj_set_style_arc_width(temp_arc, 10, LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(temp_arc, lv_color_make(230, 103, 80), LV_PART_MAIN);
    lv_obj_set_style_arc_color(temp_arc, lv_color_make(230, 103, 80), LV_PART_INDICATOR);

    // Style knob
    static lv_style_t style_knob_color;
    lv_style_init(&style_knob_color);
    lv_style_set_bg_color(&style_knob_color, lv_color_make(0xFF, 0xFF, 0xFF));
    lv_obj_add_style(temp_arc, &style_knob_color, LV_PART_KNOB);

    // Align the arc
    lv_obj_align(temp_arc, LV_ALIGN_TOP_MID, 0, 15);

    // Add temperature unit image
    lv_obj_t *img_temp_unit = lv_img_create(page);
    lv_img_set_src(img_temp_unit, &AC_unit);
    lv_obj_align(img_temp_unit, LV_ALIGN_CENTER, 50, -10);

    // Add animation for the arc
    lv_anim_t a1;
    lv_anim_init(&a1);
    lv_anim_set_var(&a1, temp_arc);
    lv_anim_set_values(&a1, lv_obj_get_y_aligned(temp_arc) - 20, lv_obj_get_y_aligned(temp_arc));
    lv_anim_set_exec_cb(&a1, (lv_anim_exec_xcb_t)lv_obj_set_y);
    lv_anim_set_path_cb(&a1, lv_anim_path_overshoot);
    lv_anim_set_time(&a1, 1200); // Animation duration
    lv_anim_start(&a1);

    // Add animation for the temperature icon
    lv_anim_t a2;
    lv_anim_init(&a2);
    lv_anim_set_var(&a2, img_thermostat_temp);
    lv_anim_set_values(&a2, lv_obj_get_y_aligned(img_thermostat_temp) + 20, lv_obj_get_y_aligned(img_thermostat_temp));
    lv_anim_set_exec_cb(&a2, (lv_anim_exec_xcb_t)lv_obj_set_y);
    lv_anim_set_path_cb(&a2, lv_anim_path_overshoot);
    lv_anim_set_time(&a2, 1200); // Animation duration
    lv_anim_start(&a2);

    // Attach thermostat events
    lv_obj_add_event_cb(page, thermostat_event_cb, LV_EVENT_FOCUSED, NULL);
    lv_obj_add_event_cb(page, thermostat_event_cb, LV_EVENT_KEY, NULL);
    lv_obj_add_event_cb(page, thermostat_event_cb, LV_EVENT_LONG_PRESSED, NULL);

    // Remove all objects from the encoder group and re-add the page
    ui_remove_all_objs_from_encoder_group();
    ui_add_obj_to_encoder_group(page);
}


static bool thermostat_layer_enter_cb(void *layer)
{
    bool ret = false;

    LV_LOG_USER("");
    lv_layer_t *create_layer = layer;
    if (NULL == create_layer->lv_obj_layer) {
        ret = true;
        create_layer->lv_obj_layer = lv_obj_create(lv_scr_act());
        lv_obj_remove_style_all(create_layer->lv_obj_layer);
        lv_obj_set_size(create_layer->lv_obj_layer, LV_HOR_RES, LV_VER_RES);

        ui_thermostat_init(create_layer->lv_obj_layer);
        set_time_out(&time_500ms, 100);
    }
    return ret;
}

static bool thermostat_layer_exit_cb(void *layer)
{
    LV_LOG_USER("");
    return true;
}

static void thermostat_layer_timer_cb(lv_timer_t *tmr)
{
    feed_clock_time();
}
