#ifndef TASKS_H
#define TASKS_H

#include "freertos/event_groups.h"

void voice_announcement_task(void *pvParameters);
extern EventGroupHandle_t event_group;
#define BIT_VOICE_ANNOUNCE (1 << 0)

#endif // TASKS_H
//creating gloable varabiles 