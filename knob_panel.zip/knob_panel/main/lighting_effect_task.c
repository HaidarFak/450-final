#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/ledc.h"  // Include the LEDC driver for PWM control
#include "lighting_effect_task.h"  // Include the header for function declarations

// LED PWM constants
#define LED_PIN 13
#define LED_FREQ_HZ 5000
#define LED_CHANNEL LEDC_CHANNEL_0
#define LED_TIMER LEDC_TIMER_0
#define LED_RESOLUTION LEDC_TIMER_13_BIT

int brightness_level = 0;
// PWM configuration function
void configure_pwm(void) {
    ledc_timer_config_t ledc_timer = {
        .speed_mode = LEDC_LOW_SPEED_MODE,  // Correct constant for high-speed mode
        .timer_num = LED_TIMER,
        .duty_resolution = LED_RESOLUTION,
        .freq_hz = LED_FREQ_HZ,
        .clk_cfg = LEDC_AUTO_CLK  // Use automatic clock selection
    };
    ledc_timer_config(&ledc_timer);

    ledc_channel_config_t ledc_channel = {
        .gpio_num = LED_PIN,          // Set the GPIO pin for LED
        .speed_mode = LEDC_LOW_SPEED_MODE,  // Use high-speed mode
        .channel = LED_CHANNEL,       // Set the channel
        .intr_type = LEDC_INTR_DISABLE,  // Disable interrupts
        .timer_sel = LED_TIMER,       // Select the timer
        .duty = 0,                    // Start with no duty cycle (off)
        .hpoint = 0                   // No high-point adjustment
    };
    ledc_channel_config(&ledc_channel);
}

// Function to get current brightness level (replace with actual implementation)
int get_brightness_level(void) {
    return brightness_level;  // Return the global brightness level
}

void set_brightness_level(int level) {
    if (xSemaphoreTake(brightness_mutex, portMAX_DELAY)) {
        brightness_level = level;
        xSemaphoreGive(brightness_mutex);
    }
}

// Fade effect for LED (25% brightness)
void fade_effect(void) {
    for (int duty = 0; duty <= 8191; duty++) {  // Gradually increase brightness
        ledc_set_duty(LEDC_LOW_SPEED_MODE, LED_CHANNEL, duty);  // Set duty cycle
        ledc_update_duty(LEDC_LOW_SPEED_MODE, LED_CHANNEL);    // Apply duty cycle
        vTaskDelay(10 / portTICK_PERIOD_MS);  // Delay for smooth fade
    }
}

// Blink effect for LED (50%, 75%, 100% brightness)
void blink_effect(int blink_interval) {
    for (int i = 0; i < 10; i++) {  // Blink 10 times
        ledc_set_duty(LEDC_LOW_SPEED_MODE, LED_CHANNEL, 8191);  // Fully on
        ledc_update_duty(LEDC_LOW_SPEED_MODE, LED_CHANNEL);     // Apply duty cycle
        vTaskDelay(blink_interval / portTICK_PERIOD_MS);         // Delay for blinking
        ledc_set_duty(LEDC_LOW_SPEED_MODE, LED_CHANNEL, 0);     // Fully off
        ledc_update_duty(LEDC_LOW_SPEED_MODE, LED_CHANNEL);     // Apply duty cycle
        vTaskDelay(blink_interval / portTICK_PERIOD_MS);         // Delay for blinking
    }
}

// Lighting effect task to change LED state based on brightness level
void lighting_effect_task(void *pvParameter) {
    while (1) {
        int current_brightness = get_brightness_level();  // Get current brightness level

        if (current_brightness == 25) {
            fade_effect();  // Fade effect for 25%
        } else if (current_brightness == 50) {
            blink_effect(1000);  // Blink effect for 50% brightness
        } else if (current_brightness == 75) {
            blink_effect(500);  // Blink effect for 75% brightness
        } else if (current_brightness == 100) {
            blink_effect(250);  // Blink effect for 100% brightness
        }

        vTaskDelay(100 / portTICK_PERIOD_MS);  // Wait before checking brightness again
    }
}
