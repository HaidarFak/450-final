#ifndef LIGHTING_EFFECT_TASK_H
#define LIGHTING_EFFECT_TASK_H

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/ledc.h"  // For LED PWM control

// Function Prototypes
void configure_pwm(void);  // PWM configuration function
void lighting_effect_task(void *pvParameter);  // The main lighting effect task

// Function declarations for fade and blink effects
void fade_effect(void);
void blink_effect(int blink_interval);
void set_brightness_level(int level);
int get_brightness_level(void);
// Extern declarations for shared variables
extern int brightness_level;  // Global variable for brightness level
extern SemaphoreHandle_t brightness_mutex;  // Mutex to protect brightness level

#endif // LIGHTING_EFFECT_TASK_H
