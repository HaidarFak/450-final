# esp-libhelix-mp3

ESP32 (and others) component for the libhelix-mp3 mp3 decoding library.
