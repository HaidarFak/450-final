#ifndef TW_SPI_ACCESS_H
#define TW_SPI_ACCESS_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int tw_upload_dsp_firmware(int mode);

#endif
